﻿using System;

namespace Problem2_BusinessRule
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            Console.WriteLine("for which product you want to pay");
            string str = Console.ReadLine();

            switch(str.ToLower())
            {
                case "physical product" :
                    PhysicalProduct pProduct = new PhysicalProduct(new PackingSlip());
                    Console.WriteLine(pProduct.createRule());
                    break;
                case "book":
                    BookProduct book = new BookProduct(new DuplicatePackingSlip());
                    Console.WriteLine(book.createRule());
                    break;

                case "membership":
                    Membership membership = new Membership(new ActivateMembership());
                    Console.WriteLine(membership.createRule());
                    break;
                case "upgrade to a membership":
                    Membership memberUpgrade = new Membership(new UpgradeMembership());
                    Console.WriteLine(memberUpgrade.createRule());
                    break;

                case "membership or upgrade":
                    Membership memberUpgradeEmail = new Membership();
                    Console.WriteLine(memberUpgradeEmail.SendEmail());
                    break;
                case "learning to ski":
                    LearningToSki learnski = new LearningToSki();
                    Console.WriteLine(learnski.createRule());
                    break;
                case "physical product or book":
                    CommissionPayment productBook = new CommissionPayment();
                    Console.WriteLine(productBook.MakePayment());
                    break;
                default :
                    Console.WriteLine("Please enter the correct option");
                    break;
            }
            Console.ReadLine();        
        }
    }
}
