﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2_BusinessRule
{
    public class CommissionPayment : IPayment
    {
        public string MakePayment()
        {
            return "generating Commission Payment";
        }
    }
}
