﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2_BusinessRule
{
    class PhysicalProduct : IRule
    {
        protected IPayment _payment;

        public PhysicalProduct(IPayment payment)
        {
            _payment = payment;
        }
        public string createRule()
        {
            return _payment.MakePayment();
        }
    }
}
