﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2_BusinessRule
{
    class DuplicatePackingSlip : IPayment
    {
        public string MakePayment()
        {
            return "Generating Duplicate Packing SLip for Royalty Department";
        }
    }
}
