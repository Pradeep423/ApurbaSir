﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2_BusinessRule
{
    class BookProduct : IRule
    {
        protected IPayment _payment;

        public BookProduct(IPayment payment)
        {
            _payment = payment;
        }
        public string createRule()
        {
            return _payment.MakePayment();
        }
    }
}
