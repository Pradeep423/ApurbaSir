﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem2_BusinessRule
{
    class ActivateMembership : IPayment
    {
        public string MakePayment()
        {
            return "activate the membership";
        }
    }
}
